# 森林小班 GIS · Codex

版本：1.5.1-codex。Windows 本地 Skill，入口为 `Tools/forest-gis.ps1`。

从 GitHub Release 下载干净 ZIP，解压后运行 `powershell -NoProfile -File install.ps1`。默认安装到 `$CODEX_HOME/skills` 或用户目录 `.codex/skills`；`-ProjectRoot` 支持项目 `.agents/skills`，`-SkillsRoot` 支持自定义目标。

Codex 中输入：`使用 $forest-compartment-gis 检查我的小班数据，先执行 doctor`。

需要 Python 3.10+，GIS 依赖见 requirements-segmentation.txt。GDB 构建需要已授权的 ArcGIS Pro。初次运行使用 doctor；缺少依赖时明确报告环境问题。自动 APRX 创建禁用，使用 docs/ArcGISPro_手动创建小班项目.md。

inspect/validate 会生成报告，请指定独立输出目录。候选小班须人工核查。退出码 2 表示存在质量问题；低层入口还可能返回通用错误码 1，须读取 stderr，不能仅依赖退出码表。

源仓库发布流程见仓库根目录 README.md；本包不包含旧版多平台生成器。
